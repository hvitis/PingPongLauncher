PingPongThrower POC phase 4: Aim

Bambu Lab A1, 0.4 mm nozzle, 0.2 mm layers, 10 % gyroid infill, Bambu PETG Basic @BBL A1, supports off. Open each .3mf in Bambu Studio; every copy is already on the plate.

  tray.3mf  ×1  Base box. 4 walls.
  lid.3mf  ×1  Base lid, printed upside down (bearing boss up). 4 walls.
  spacer_parts.3mf  ×1  Bearing spacer + 2 inner-race shims (3 rings, one plate). 6 walls.
  coupler.3mf  ×1  Servo-to-nut coupler. 6 walls.
  turret.3mf  ×1  Turret plate. 6 walls.
