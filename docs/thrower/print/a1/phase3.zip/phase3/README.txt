PingPongThrower POC phase 3: Feed

Bambu Lab A1, 0.4 mm nozzle, 0.2 mm layers, 10 % gyroid infill, Bambu PETG Basic @BBL A1, supports off. Open each .3mf in Bambu Studio; every copy is already on the plate.

  feed_tube.3mf  ×1  Feed tube with ears and servo plate, upright. 4 walls.
  rocker.3mf  ×1  Escapement rocker, flat, horn recess up. 6 walls.
  hopper.3mf  ×1  Basket adapter funnel, printed upside down (collar on the bed). 3 walls.
