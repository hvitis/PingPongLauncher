PingPongThrower POC phase 5: Panel

Bambu Lab A1, 0.4 mm nozzle, 0.2 mm layers, 10 % gyroid infill, Bambu PETG Basic @BBL A1, supports off. Open each .3mf in Bambu Studio; every copy is already on the plate.

  knob_pot.3mf  ×3  Potentiometer knob (6 mm D-shaft). 3 walls.
