PingPongThrower POC phase 1: Head

Bambu Lab A1, 0.4 mm nozzle, 0.2 mm layers, 10 % gyroid infill, Bambu PETG Basic @BBL A1, supports off. Open each .3mf in Bambu Studio; every copy is already on the plate.

  head_left.3mf  ×1  Launcher head half, lies on its outer wall. 4 walls.
  head_right.3mf  ×1  Launcher head half with the motor pockets. 4 walls.
  motor_clamp.3mf  ×2  N20 clamp, flange down. 6 walls.
  wheel_hub.3mf  ×3  N20 D-shaft to wheel hub (TT-shaft stub, or LEGO cross with wheel_type = "lego"), lies on its side (1 spare). 6 walls.
