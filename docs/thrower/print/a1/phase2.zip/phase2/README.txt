PingPongThrower POC phase 2: Throw rig

Bambu Lab A1, 0.4 mm nozzle, 0.2 mm layers, 10 % gyroid infill, Bambu PETG Basic @BBL A1, supports off. Open each .3mf in Bambu Studio; every copy is already on the plate.

  poc_base.3mf  ×1  Bench plate for POC test phases 2–3, flat. 6 walls.
  cheek_left.3mf  ×1  Yoke cheek, lies on its outer face. 6 walls.
  cheek_right.3mf  ×1  Yoke cheek (mirror of the left). 6 walls.
  knob_lock.3mf  ×2  Elevation lock knob, press an M4×20 hex bolt in. 5 walls.
